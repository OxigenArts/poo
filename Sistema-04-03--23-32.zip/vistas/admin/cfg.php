<?php
require_once 'classes/imagenes.php';
require_once 'classes/config.php';
$cfg = new Config();
$imagen = new Imagen();
if(isset($_POST['submit'])){
	if(!empty($_REQUEST['titulo']) && !empty($_REQUEST['nombre'])){
		$idimagen = $imagen->Subir($_FILES['imagen']);
		if($idimagen != false){
			$imagen->setId($cfg->getLogo());
			$imagen->Delete();
		}
		$cfg->setTitulo($_REQUEST['titulo']);
		$cfg->setDescripcion($_REQUEST['descripcion']);
		$cfg->setNombre($_REQUEST['nombre']);
		$cfg->setLogo($idimagen[0]);
		if($cfg->Update()){
			echo '<script>window.location.href = window.location.pathname;</script>';
			$mensaje = '<span class="success">Configuracion actualizada correctamente!</span>';
		}	
		else{
			$mensaje = '<span class="error">Ocurrio un error, intenta nuevamente. Si el problema persiste contacte a un administrador.</span>';
		}	
	}
	else{
		$mensaje = '<span class="error">Ocurrio un error, verifique los campos.</span>';
	}
	
}
else{
	$imagen->setId($cfg->getLogo());
	$mensaje = "";
}

?>

<h1>Configuracion General</h1>
<p>Rellene el formulario para cambiar la configuracion general del sitio.</p>
<p>Los campos marcados con <span class="red">*</span> son obligatorios</p>
<?php echo $mensaje; ?>
<section id="lista">
	<article>
<form action="" method="post" enctype="multipart/form-data">

	<h2><span class="red">*</span> Titulo de la web:<h2>
	<input required name="titulo" value="<?php echo $cfg->getTitulo(); ?>" type="text">

	<h2> Descripcion de la web:<h2>
	<input required name="descripcion" value="<?php echo $cfg->getDescripcion(); ?>" type="text">

	<h2><span class="red">*</span> Nombre de empresa:<h2>
	<input required name="nombre" value="<?php echo $cfg->getNombre(); ?>" type="text">
	<img class="realsize" src="<?php echo $imagen->getUrl(); ?>">
	<h2><span class="red">*</span> Logo:</h2>
	<input name="imagen" type="file">

	<input class="azul" name="submit" type="submit" value="Guardar">
</form>
</article>
</section>
