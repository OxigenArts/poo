<?php
class Audio extends Database {
	private $id, $ruta;
	private $table;
	private $datos = array();
	public function __construct() {
		$con = parent::conexion();
		$this->table = "audios";
		$table = $this->table;
		$result = $con->query("show tables like '$table'");
		if($result->fetch_row() == false){
			$con->query("
			CREATE TABLE $table
			(
			id INT UNSIGNED AUTO_INCREMENT,
			url VARCHAR(512),
			PRIMARY KEY(id)
			);");
		}
	}
	public function setId(){
		$this->id = $id;
	}

	public function getUrl($table2,$id){
		$con = parent::conexion();
		$q_table2 = $con->real_escape_string($table2);
		$q_table = $con->real_escape_string($this->table);
		$q_id = $con->real_escape_string($id);
		if($query = $con->query("select audio from $q_table2 where id='$q_id'")){
			if ($row = $query->fetch_row()) {
				$img_id = $row[0]; 
				return parent::getById($this->table,$img_id)[1];
			}
		}	
		else{
			return false;
		}
	}
	public function Subir($file){
		$con = parent::conexion();
		if ($file["error"] > 0){
			return false;
		} 
		else {

			$permitidos = array("audio/mpeg", "	audio/vnd.wav");
			$limite_kb = 10;
			if (in_array($file['type'], $permitidos) && $file['size'] <= $limite_kb * 1024000){
				$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
				$newname = sha1($file['name'].rand()).".".$ext;
				$ruta = "contenido/audios/" . $newname;
				if (@move_uploaded_file($file["tmp_name"], $ruta)){
					$table = $con->real_escape_string($this->table);
					$ruta = $con->real_escape_string($ruta);
					$this->ruta = $ruta;
					$con->query("INSERT INTO $table (url) values('$ruta')");
					$result = $con->query("SELECT id FROM $table WHERE url='$ruta'");
					while($urlid = $result->fetch_row())
					{
						$this->id = $urlid[0];
						return $this->id;
					}
				} else {
				return false;
				}
			} 
			else {
			return false;
			}
		}
		mysqli_close($con);
	}
	public function Delete(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$id = $this->id;
			if($con->query("DELETE from $table where id='$id'")){
					return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		
		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
}
?>