<?php
class Core {
	
	private $ruta; 
	public function __construct($route) {	
	include('classes/mysql.php');
	include('classes/enrutador.php');
	$this->ruta = new Rutas($route);
	}
	public function addClass($clase,$name){
		include('classes/'.$clase.'.php');
		return new $name;
	}
	public function agregarRuta($ruta,$vista){
		$this->ruta->agregarRuta($ruta,$vista);
	}
	public function Start(){
		$this->ruta->Start();
	}

}
?>
