<?php
class Database {
	private $host, $user, $pass, $database;
	public function __construct() {	
	}
	public function conexion(){
		$db_cfg = require 'config/database.php';
		$this->host=$db_cfg['host'];
		$this->user=$db_cfg['user'];
		$this->pass=$db_cfg['pass'];
		$this->database=$db_cfg['database'];
		$con = new mysqli($this->host,$this->user,$this->pass,$this->database);
		return $con;
	}
	public function getById($table,$id){
		$con = $this->conexion();
		$q_table = $con->real_escape_string($table);
		$q_id = $con->real_escape_string($id);
		$query = $con->query("select * from $q_table where id='$q_id'");
		while ($row = $query->fetch_row()) {
			$resultSet=$row;
		}
		return $resultSet;
		mysqli_close($con);
	}
}
?>
