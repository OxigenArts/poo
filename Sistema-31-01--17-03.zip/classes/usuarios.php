<?php

class Usuario extends Database {
	private $id, $user, $pass, $email,$img;
	private $table;
	private $datos = array();
	public function __construct() {
		$con = parent::conexion();
		$this->table = "usuarios";
		$table = $this->table;
		$result = $con->query("show tables like '$table'");
		if($result->fetch_row() == false){
			$con->query("
			CREATE TABLE $table
			(
			id INT UNSIGNED AUTO_INCREMENT,
			usuario VARCHAR(14),
			pass VARCHAR(40),
			email VARCHAR(128),
			img INT,
			PRIMARY KEY(id)
			);");
		}
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::getById($this->table,$id);
		$this->user = $this->datos[1];
		$this->pass = $this->datos[2];
		$this->email = $this->datos[3];
		$this->img = $this->datos[4];
	}
	public function getId(){
		if($this->id != null){
			return $this->id;
		}
		else{
			return false;
		}
	}
	public function getUser(){
		if($this->user != null){
			return $this->user;
		}
		else{
			return false;
		}
	}
	public function setUser($user){
		$this->user = $user;
	}
	public function getPass(){
		if($this->pass != null){
			return $this->pass;
		}
		else{
			return false;
		}
	}
	public function setPass($pass){
		$this->pass = $pass;
	}
	public function getEmail(){
		if($this->email != null){
			return $this->email;
		}
		else{
			return false;
		}
	}
	public function setEmail($email){
		$this->email = $email;
	}	
	public function getImagen(){
		if($this->img != null){
			return $this->img;
		}
		else{
			return false;
		}
	}
	public function setImagen($img){
		$this->img = $img;
	}
	public function Save(){
		$con = parent::conexion();
		$table = $con->real_escape_string($this->table);
		$user = $con->real_escape_string($this->user);
		$pass = $con->real_escape_string(sha1($this->pass));
		$email = $con->real_escape_string($this->email);
		$img = $con->real_escape_string($this->img);
		if($con->query("INSERT INTO $table (usuario,pass,email,img) values('$user','$pass','$email','$img')")){
			return true;
		}
		else{
			mysqli_close($con);
			return false;
		}
		mysqli_close($con);
	}
	public function Update(){
		if($this->id != null){
		$con = parent::conexion();
		$table = $con->real_escape_string($this->table);
		$user = $con->real_escape_string($this->user);
		$pass = $con->real_escape_string(sha1($this->pass));
		$email = $con->real_escape_string($this->email);
		$img = $con->real_escape_string($this->img);
		$id = $this->id;
		
		if($con->query("UPDATE $table SET usuario = '$user', pass ='$pass' , email ='$email', img ='$img' where id='$id'")){
			return true;
		}
		else{
			mysqli_close($con);
			return false;
		}
		mysqli_close($con);

		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
	public function Delete(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$id = $this->id;
			if($con->query("DELETE from $table where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
}
?>