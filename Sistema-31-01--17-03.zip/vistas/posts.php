<?php
require_once 'classes/posts.php';
require_once 'classes/imagenes.php';

if(isset($_POST['submit'])){
$img = new Imagen();

$u = new Post();//tankiu
$u->setId("1");
print_r($u->getTags());
print($u->getTitulo());

}
?>
<form method="post" action="http://190.182.188.72/poo/posts" enctype="multipart/form-data">
<input type="text" name="titulo"><br>
<input type="text" name="cont"><br>
<input type="text" name="aut"><br>
<input type="text" name="date"><br>
<input type="text" name="tags"><br>
<input type="file" name="img"><br>
<input type="submit" name="submit" value="Submit Form"><br>
</form>