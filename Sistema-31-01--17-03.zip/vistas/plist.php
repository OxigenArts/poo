<?php
require_once 'classes/playlist.php';
require_once 'classes/audios.php';
if(isset($_POST['submit'])){
$p = new Playlist();
$aud = new Audio();
$p->setId("1");
$audioid = $p->getAudio();
$audiourl = $aud->getUrl("playlist",$p->getId());
echo '<audio src="'.$audiourl.'" autoplay controls></audio>';

}
?>
<form method="post" action="http://localhost/poo/playlist" enctype="multipart/form-data">
<input type="text" name="titulo"><br>
<input type="file" name="img"><br>
<input type="file" name="audio"><br>
<input type="submit" name="submit" value="Submit Form"><br>
</form>