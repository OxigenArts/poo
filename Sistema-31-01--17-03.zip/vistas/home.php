<?php
require_once 'classes/programas.php';

require_once 'classes/imagenes.php';
if(isset($_POST['submit'])){
$img = new Imagen();
$p = new Programa();
$p->setTitulo($_REQUEST['titulo']);
$p->setLocutor($_REQUEST['locutor']);
$p->setHora1($_REQUEST['hora1']);
$p->setHora2($_REQUEST['hora2']);
$p->setDescripcion($_REQUEST['descripcion']);
$p->setImagen($img->Subir($_FILES['img']));
if($p->Save()){
echo "SAPE";
}
else{
	echo "no sape :c";
}

}
?>
<form method="post" action="http://190.182.188.72/poo/programas" enctype="multipart/form-data">
<input type="text" name="titulo"><br>
<input type="text" name="locutor"><br>
<input type="text" name="hora1"><br>
<input type="text" name="hora2"><br>
<input type="text" name="descripcion"><br>
<input type="file" name="img"><br>
<input type="submit" name="submit" value="Submit Form"><br>
</form>