<?php
require_once 'classes/usuarios.php';
require_once 'classes/imagenes.php';
if(isset($_POST['submit'])){
$img = new Imagen();
$u = new Usuario();//tankiu
$u->setId("2");
print $u->getUser();
//asi estaria?
}
?>
<form method="post" action="http://190.182.188.72/poo/usuarios" enctype="multipart/form-data">
<input type="text" name="user"><br>
<input type="text" name="pass"><br>
<input type="text" name="email"><br>
<input type="file" name="img"><br>
<input type="submit" name="submit" value="Submit Form"><br>
</form>