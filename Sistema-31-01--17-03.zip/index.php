
<?php
require_once 'classes/mysql.php';
require_once 'classes/enrutador.php';

$r = new Rutas($_REQUEST['route']);
$r->agregarRuta("programas","home");//este lo probamos? y a lo probamos?
$r->agregarRuta("usuarios","users");
$r->agregarRuta("posts","posts");
$r->agregarRuta("playlist","plist");// las plist papa
$r->agregarRuta("config","cfg");
$_URL_BASE="http://localhost/poo/";
echo '<base href = "'.$_URL_BASE.'" target="_top" />';
$r->Start();



?>
