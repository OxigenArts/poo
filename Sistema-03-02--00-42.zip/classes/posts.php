<?php
class Post extends Database {
	private $id, $titulo, $contenido, $autor, $fecha,$tags,$img;
	private $table;
	private $datos = array();
	public function __construct() {
		$con = parent::conexion();
		$this->table = "posts";
		$table = $this->table;
		$result = $con->query("show tables like '$table'");
		if($result->fetch_row() == false){
			$con->query("
			CREATE TABLE $table
			(
			id INT UNSIGNED AUTO_INCREMENT,
			titulo VARCHAR(128),
			contenido TEXT,
			autor INT,
			fecha DATE,
			tags VARCHAR(256),
			img INT,
			PRIMARY KEY(id)
			);");
		}
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::getById($this->table,$id);
		$this->titulo = $this->datos[1];
		$this->contenido = $this->datos[2];
		$this->autor = $this->datos[3];
		$this->fecha = $this->datos[4];
		$this->tags = $this->datos[5];
		$this->img = $this->datos[6];
	}
	public function getId(){
		if($this->id != null){
			return $this->id;
		}
		else{
			return false;
		}
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getContenido(){
		if($this->contenido != null){
			return $this->contenido;
		}
		else{
			return false;
		}
	}
	public function setContenido($contenido){
		$this->contenido = $contenido;
	}
	public function getAutor(){
		if($this->autor != null){
			return $this->autor;
		}
		else{
			return false;
		}
	}
	public function setAutor($autor){
		$this->autor = $autor;//WUT
	}
	public function getFecha(){
		if($this->fecha != null){
			return $this->fecha;
		}
		else{
			return false;
		}
	}
	public function setFecha($fecha){
		$this->fecha = $fecha;
	}
	public function getTags(){
		if($this->tags != null){
			$a_tags = preg_split("/[,]+/", $this->tags, 0, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
			return $a_tags;
		}
		else{
			return false;
		}
	}
	public function setTags($tags){
		$this->tags = $tags;
	}
	public function getImagen(){
		if($this->img != null){
			return $this->img;
		}
		else{
			return false;
		}
	}
	public function setImagen($img){
		$this->img = $img;
	}
	public function Save(){
		$con = parent::conexion();
		$table = $con->real_escape_string($this->table);
		$titulo = $con->real_escape_string($this->titulo);
		$contenido = $con->real_escape_string($this->contenido);
		$autor = $con->real_escape_string($this->autor);
		$fecha = $con->real_escape_string($this->fecha);
		$tags = $con->real_escape_string($this->tags);
		$img = $con->real_escape_string($this->img);
		if($con->query("INSERT INTO $table (titulo,contenido,autor,fecha,tags,img) values('$titulo','$contenido','$autor','$fecha','$tags','$img')")){
			return true;
		}
		else{
			mysqli_close($con);
			return false;
		}
	}
	public function Update(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$titulo = $con->real_escape_string($this->titulo);
			$contenido = $con->real_escape_string($this->contenido);
			$autor = $con->real_escape_string($this->autor);
			$fecha = $con->real_escape_string($this->fecha);
			$tags = $con->real_escape_string($this->tags);
			$id = $this->id;
			if($con->query("UPDATE $table SET titulo = '$titulo', contenido ='$contenido' , autor ='$autor', fecha ='$fecha', tags ='$tags', img = '$img' where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}
		else{
			return false;
		}
	}
	public function Delete(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$id = $this->id;
			if($con->query("DELETE from $table where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>