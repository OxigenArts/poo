<?php
class Config extends Database {
	private $id, $titulo, $nombre, $logo,$descripcion,$color;
	private $table;
	private $datos = array();

	public function __construct() {
		$con = parent::conexion();
		$this->table = "config";
		$this->setId("1");
		$table = $this->table;
		$result = $con->query("show tables like '$table'");
		if($result->fetch_row() == false){
			$con->query("
			CREATE TABLE $table
			(
			id INT UNSIGNED AUTO_INCREMENT,
			nombre VARCHAR(128),
			titulo VARCHAR(128),
			descripcion TEXT,
			img INT,
			color VARCHAR(11),
			PRIMARY KEY(id)
			);");
		}
		
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::getById($this->table,$id);
		$this->titulo = $this->datos[1];
		$this->contenido = $this->datos[2];
		$this->autor = $this->datos[3];
		$this->fecha = $this->datos[4];
		$this->tags = $this->datos[5];
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getNombre(){
		if($this->nombre != null){
			return $this->nombre;
		}
		else{
			return false;
		}
	}
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}
	public function getLogo(){
		if($this->logo != null){
			return $this->logo;
		}
		else{
			return false;
		}
	}
	public function setLogo($logo){
		$this->logo = $logo;//WUT
	}
	public function getDescripcion(){
		if($this->descripcion != null){
			return $this->descripcion;
		}
		else{
			return false;
		}
	}
	public function setDescripcion($descripcion){
		$this->descripcion = $descripcion;
	}
	public function getColor(){
		if($this->color != null){
			return $this->color;
		}
		else{
			return false;
		}
	}
	public function setColor($color){
		$this->color = $color;
	}
	public function Update(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$titulo = $con->real_escape_string($this->titulo);
			$nombre = $con->real_escape_string($this->nombre);
			$logo = $con->real_escape_string($this->logo);
			$descripcion = $con->real_escape_string($this->descripcion);
			$color = $con->real_escape_string($this->color);
			$id = $this->id;
			if($con->query("UPDATE $table SET titulo = '$titulo', nombre ='$nombre' , logo ='$logo', descripcion ='$descripcion', color ='$color' where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>