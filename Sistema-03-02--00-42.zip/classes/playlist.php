<?php

class Playlist extends Database {
	private $id, $titulo, $img, $audio;
	private $table;
	private $datos = array();
	public function __construct() {
		$con = parent::conexion();
		$this->table = "playlist";
		$table = $this->table;
		$result = $con->query("show tables like '$table'");
		if($result->fetch_row() == false){
			$con->query("
			CREATE TABLE $table
			(
			id INT UNSIGNED AUTO_INCREMENT,
			titulo VARCHAR(256),
			img INT,
			audio INT,
			PRIMARY KEY(id)
			);");
		}
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::getById($this->table,$id);
		$this->titulo = $this->datos[1];
		$this->img = $this->datos[2];
		$this->audio = $this->datos[3];
	}
	public function getId(){
		if($this->id != null){
			return $this->id;
		}
		else{
			return false;
		}
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getImagen(){
		if($this->img != null){
			return $this->img;
		}
		else{
			return false;
		}
	}
	public function setImagen($img){
		$this->img = $img;
	}
	public function getAudio(){
		if($this->audio != null){
			return $this->audio;
		}
		else{
			return false;
		}
	}
	public function setAudio($audio){
		$this->audio = $audio;
	}	
	public function Save(){
		$con = parent::conexion();
		$table = $con->real_escape_string($this->table);
		$titulo = $con->real_escape_string($this->titulo);
		$img = $con->real_escape_string($this->img);
		$audio = $con->real_escape_string($this->audio);
		if($con->query("INSERT INTO $table (titulo,img,audio) values('$titulo','$img','$audio')")){
			return true;
		}
		else{
			mysqli_close($con);
			return false;
		}
		mysqli_close($con);
	}
	public function Update(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$titulo = $con->real_escape_string($this->titulo);
			$img = $con->real_escape_string($this->img);
			$audio = $con->real_escape_string($this->audio);
			$id = $this->id;
			if($con->query("UPDATE $table SET titulo = '$titulo', img ='$img' , audio ='$audio' where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
	public function Delete(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$id = $this->id;
			if($con->query("DELETE from $table where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
}
?>