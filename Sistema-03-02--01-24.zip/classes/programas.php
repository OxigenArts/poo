<?php
class Programa extends Database {
	private $id, $titulo, $locutor, $hora1,$hora2,$descripcion,$img;
	private $table;
	private $datos = array();
	public function __construct() {
		$con = parent::conexion();
		$this->table = "programas";
		$table = $this->table;
		$result = $con->query("show tables like '$table'");
		if($result->fetch_row() == false){
			$con->query("
			CREATE TABLE $table
			(
			id INT UNSIGNED AUTO_INCREMENT,
			titulo VARCHAR(128),
			locutor VARCHAR(128),
			hora1 TIME,
			hora2 TIME,
			descripcion TEXT,
			img INT,
			PRIMARY KEY(id)
			);");
		}
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::getById($this->table,$id);
		$this->titulo = $this->datos[1];
		$this->locutor = $this->datos[2];
		$this->hora1 = $this->datos[3];
		$this->hora2 = $this->datos[4];
		$this->descripcion = $this->datos[5];
		$this->img = $this->datos[6];
	}
	public function getId(){
		if($this->id != null){
			return $this->id;
		}
		else{
			return false;
		}
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getLocutor(){
		if($this->locutor != null){
			return $this->locutor;
		}
		else{
			return false;
		}
	}
	public function setLocutor($locutor){
		$this->locutor = $locutor;
	}
	public function getHora1(){
		if($this->hora1 != null){
			return $this->hora1;
		}
		else{
			return false;
		}
	}
	public function setHora1($hora1){
		$this->hora1 = $hora1;
	}	
	public function getHora2(){
		if($this->hora2 != null){
			return $this->hora2;
		}
		else{
			return false;
		}
	}
	public function setHora2($hora2){
		$this->hora2 = $hora2;
	}
	public function getDescripcion(){
		if($this->descripcion != null){
			return $this->descripcion;
		}
		else{
			return false;
		}
	}
	public function setDescripcion($descripcion){
		$this->descripcion = $descripcion;
	}
	public function getImagen(){
		if($this->img != null){
			return $this->img;
		}
		else{
			return false;
		}
	}
	public function setImagen($img){
		$this->img = $img;
	}
	public function Save(){
		$con = parent::conexion();
		$table = $con->real_escape_string($this->table);
		$titulo = $con->real_escape_string($this->titulo);
		$locutor = $con->real_escape_string($this->locutor);
		$hora1 = $con->real_escape_string($this->hora1);
		$hora2 = $con->real_escape_string($this->hora2);
		$descripcion = $con->real_escape_string($this->descripcion);
		$img = $con->real_escape_string($this->img);
		if($con->query("INSERT INTO $table (titulo,locutor,hora1,hora2,descripcion,img) values('$titulo','$locutor','$hora1','$hora2','$descripcion','$img')")){
			return true;
		}
		else{
			mysqli_close($con);
			return false;
		}
		mysqli_close($con);
	}
	public function Update(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$titulo = $con->real_escape_string($this->titulo);
			$locutor = $con->real_escape_string($this->locutor);
			$hora1 = $con->real_escape_string($this->hora1);
			$hora2 = $con->real_escape_string($this->hora2);
			$descripcion = $con->real_escape_string($this->descripcion);
			$img = $con->real_escape_string($this->img);
			$id = $this->id;
			if($con->query("UPDATE $table SET titulo = '$titulo', locutor ='$locutor' , hora1 ='$hora1', hora2 ='$hora2', descripcion ='$descripcion', img ='$img' where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
	public function Delete(){
		if($this->id != null){
			$con = parent::conexion();
			$table = $con->real_escape_string($this->table);
			$id = $this->id;
			if($con->query("DELETE from $table where id='$id'")){
				return true;
			}
			else{
				mysqli_close($con);
				return false;
			}
		}	
		else{
			return false;
		}
		mysqli_close($con);
	}
}
?>