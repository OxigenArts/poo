<?php
class Rutas{
	private $g_route;
	private $rutas = array();
	function __construct($route){
		$this->g_route = $route;
	}
	function agregarRuta($ruta,$vista){
		$this->rutas[$ruta] = $vista;
	}
	function Start(){

		$b = false;
		foreach ($this->rutas as $ruta => $vista) {
			if($this->g_route == $ruta || $this->g_route == $ruta.'/'){
				$this->mostrarVista($vista);
				$b= true;
				break;
			}
		}
		if(!$b){
			$this->mostrarVista("404");
		}
	}
	function mostrarVista($vista){
		include("vistas/".$vista.".php"); //
	}
}
?>