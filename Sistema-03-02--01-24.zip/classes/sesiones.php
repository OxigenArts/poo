<?php

class Sesion extends Database {
	private $id, $user, $pass;
	public function __construct() {
		if (session_status() == PHP_SESSION_NONE) {//esto funciona?
    		session_start();
		}
	}
	public function setUser($user){
		$this->user = $user;
	}
	public function setPass($pass){
		$this->pass = $pass;
	}
	public function Conectar(){
		$con = parent::conexion();
		$user = $con->real_escape_string($this->user);
		$pass = sha1($this->pass);
		$res = $con->query("SELECT id,pass FROM usuarios WHERE  usuario='$user'");
		if($reg = $res->fetch_array()){
			if($pass == $reg[1]) {
				$this->Iniciar($reg[0]);
			} else {
				return false;

			}
		}
	}
	public function Iniciar($id){
		$_SESSION['conected'] = true;
		$_SESSION['id'] = $this->id;
	}
	public function Cerrar(){
		if(isset($_SESSION['conected'])){
			$_SESSION['conected'] = false;
			$_SESSION['id'] = false;
		}
	}
	public function Verificar(){
		
		if(isset($_SESSION['conected']) && $_SESSION['conected'] == true){
			return true;
		}
		else{
			return false;
		}
	}
}
?>