<?php
require_once 'classes/mysql.php';
require_once 'classes/enrutador.php';
$r = new Rutas($_REQUEST['route']);
$r->agregarRuta("","home");//index
$r->Start();
?>
