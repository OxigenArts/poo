<?php

require_once 'classes/sesiones.php';
$sesion = new Sesion();
$sesion->Cerrar();
$sesion->setUser("UsuarioPrueba");
$sesion->setPass("123");
$sesion->Conectar();
?>