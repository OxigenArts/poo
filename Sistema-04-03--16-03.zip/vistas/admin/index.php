<!DOCTYPE html>
<html>
<head>
	<?php
	require_once 'classes/imagenes.php';
	require_once 'classes/config.php';
	require_once 'classes/sesiones.php';
	require_once 'classes/usuarios.php';
	require_once 'classes/secadm.php';
	$conf = new Config();
	if(isset($_GET['id'])){//si existe la variable get 
		$secid = $_GET['id'];//la almacena aqyui
	}
	else{
		$secid = "1";// sino establece el id 1 por defecto
	}
	$sesion = new Sesion();
	$u = new Usuario();
	$u->setId($sesion->getId());
	if($sesion->Verificar() == true){ 
		if($u->getPrivilegio() != "1"){//si no es admin
			header("location: ".$conf->getUrl());
		}
	}
	else{
		header("location: ".$conf->getUrl()."login");
	}
	$logoimg = new Imagen();
	$userimg = new Imagen();
	$seccion = new SeccionAdmin();
	$seccion->setId($secid);
	$allsecs = $seccion->getAll();
	$logoimg->setId($conf->getLogo());
	$urllogo = $logoimg->getUrl();
	$titulo = $conf->getNombre();
	
	$userimg->setId($u->getImagen());
	$urluser = $userimg->getUrl();
	$username = $u->getUser();
	?>
	<title><?php print $titulo." - Admin".$u->getPrivilegio(); ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<base href="<?php echo $conf->getUrl(); ?>/vistas/admin/"></base>
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	</head>
<body>
<div id="loader">
<div class="loader"></div>
</div>
	<script>
	var loader = document.getElementById('loader');
	var body = document.body;
	body.onload=function(){
		loader.setAttribute("style", "display:none");
    };
	</script> 
<header>
	<div id="logo">
	<i class="fa fa-bars"></i>
	<img src="<?php print $urllogo; ?>">
	</div>
	<div id="user">
	<img src="<?php print $urluser; ?>">
	<h1><?php print $username; ?></h1>
	</div>
</header>
<section id="menu">
	<ul>
		<?php 
		foreach ($allsecs as $key => $value) {
			echo'<a href="'.$conf->getUrl().'admin/'.$value['id'].'"><li>'.$value['titulo'].'</li></a>';
		}
		?>
	</ul>
</section>
<section id="body">
	<?php
	$archivoseccion = $seccion->getArchivo();
	if($archivoseccion != ""){
		@include($archivoseccion);
	}
	
	?>
</section>
</body>
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript">
	var menu = "#menu";
	$(document).ready(function(){
		$("header #logo i").click(function(){
		if($(menu).css("visibility") == "hidden"){
			$(menu).css("opacity","1");
			$(menu).css("visibility","visible");
		}
		else{
			$(menu).css("opacity","0");
			$(menu).css("visibility","hidden");
		}
		});

	});
	$(window).on('resize', function(){
		if($("body").width() > 780){
			$(menu).css("opacity","1");
			$(menu).css("visibility","visible");
		}
	});
</script>
</html>