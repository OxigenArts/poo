<footer>
	<ul>
		<li><a href="#">Oxigen.com</a></li> 
		<li>Otro texto</li>
	</ul>
</footer>