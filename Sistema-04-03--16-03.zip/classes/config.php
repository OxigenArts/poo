<?php
/*
* Modulo: Config
* Version: 0.1A
* Dependencias:
* --Database.
* 
* Manejador para configuraciones generales del sitio.
*/
class Config extends Database {
	private $id, $titulo, $nombre, $logo,$descripcion,$tema,$url;
	private $table;
	private $datos = array();
	public function __construct() {
		$this->table = "config";
		if(parent::Create($this->table,"id INT UNSIGNED AUTO_INCREMENT,nombre VARCHAR(128),titulo VARCHAR(128),descripcion TEXT,img INT,tema INT,url VARCHAR(512),PRIMARY KEY(id)")){
			$this->setId("1");
			return true;
		}
		else{
			$this->setId("1");
			return false;
		}
		
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::Select("*",$this->table,"id",$id);
		$this->nombre = $this->datos[1];
		$this->titulo = $this->datos[2];
		$this->descripcion = $this->datos[3];
		$this->logo = $this->datos[4];
		$this->tema = $this->datos[5];
		$this->url = $this->datos[6];
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getNombre(){
		if($this->nombre != null){
			return $this->nombre;
		}
		else{
			return false;
		}
	}
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}
	public function getLogo(){
		if($this->logo != null){
			return $this->logo;
		}
		else{
			return false;
		}
	}
	public function setLogo($logo){
		if(!empty($logo)){
			$this->logo = $logo;
		}
	}
	public function getDescripcion(){
		if($this->descripcion != null){
			return $this->descripcion;
		}
		else{
			return false;
		}
	}
	public function setDescripcion($descripcion){
		$this->descripcion = $descripcion;
	}
	public function getTema(){
		if($this->tema != null){
			return $this->tema;
		}
		else{
			return false;
		}
	}
	public function setTema($tema){
		if(!empty($tema)){
			$this->tema = $tema;
		}
	}
	public function getUrl(){
		if($this->url != null){
			return $this->url;
		}
		else{
			return false;
		}
	}
	public function setUrl($url){
		if(!empty($url)){
			$this->url = $url;
		}
	}
	public function Update(){
		if($this->id != null){
			if(parent::Update($this->table,array("titulo" =>$this->titulo,"nombre" =>$this->nombre,"img" =>$this->logo,"descripcion" =>$this->descripcion,"tema" =>$this->tema,"url" =>$this->url),"id",$this->id)){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>