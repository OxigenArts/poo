<?php
/*
* Modulo: Usuario
* Version: 0.1A
* Dependencias:
* --Database.
* --Imagen.
*
* Manejador de cuentas de usuarios.
*/
class Usuario extends Database {
	private $id, $user, $pass, $email,$img;
	private $table;
	private $datos = array();
	public function __construct() {
		$this->table = "usuarios";
		if(parent::Create($this->table,
		"id INT UNSIGNED AUTO_INCREMENT,usuario VARCHAR(14),pass VARCHAR(40),email VARCHAR(128),img INT,PRIMARY KEY(id)")){
			return true;
		}
		else{
			return false;
		}
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::Select("*",$this->table,"id",$id);
		$this->user = $this->datos[1];
		$this->pass = $this->datos[2];
		$this->email = $this->datos[3];
		$this->img = $this->datos[4];
	}
	public function getId(){
		if($this->id != null){
			return $this->id;
		}
		else{
			return false;
		}
	}
	public function getUser(){
		if($this->user != null){
			return $this->user;
		}
		else{
			return false;
		}
	}
	public function setUser($user){
		$this->user = $user;
	}
	public function getPass(){
		if($this->pass != null){
			return $this->pass;
		}
		else{
			return false;
		}
	}
	public function setPass($pass){
		$this->pass = $pass;
	}
	public function getEmail(){
		if($this->email != null){
			return $this->email;
		}
		else{
			return false;
		}
	}
	public function setEmail($email){
		$this->email = $email;
	}	
	public function getImagen(){
		if($this->img != null){
			return $this->img;
		}
		else{
			return false;
		}
	}
	public function setImagen($img){
		$this->img = $img;
	}
	public function Save(){
		if(parent::Insert($this->table,"usuario,pass,email,img",array($this->user,$this->pass,$this->email,$this->img))){
			return true;
		}
		else{
			return false;
		}
	}
	public function Update(){
		if($this->id != null){
			if(parent::Update($this->table,array("usuario" =>$this->user,"pass" =>$this->pass,"email" =>$this->email,"img" =>$this->img),"id",$this->id)){
				return true;
			}
			else{
				return false;
			}
		}	
		else{
			return false;
		}
	}
	public function Delete(){
		if($this->id != null){
			if(parent::Delete($this->table,"id",$this->id)) {
				return true;
			} else {
				return false;
			}
		} 
		else {
			return flase;
		}
	}
}
?>