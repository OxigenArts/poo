<?php
/*
* Modulo: SeccionAdmin
* Version: 0.1A
* Dependencias:
* --Database.
*
* Manejador de Secciones en el panel de Administracion.
*/
class SeccionAdmin extends Database {
	private $id, $titulo, $archivo;
	private $table;
	private $datos = array();
	public function __construct() {
		$this->table = "secadm";
		if(parent::Create($this->table,
		"id INT UNSIGNED AUTO_INCREMENT, titulo VARCHAR(128), archivo VARCHAR(128), privilegio INT, PRIMARY KEY(id)")){
			return true;
		}
		else{
			return false;
		}
	}
	public function getAll(){
		return parent::SelectAll("*",$this->table);
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::Select("*",$this->table,"id",$id);
		$this->titulo = $this->datos[1];
		$this->archivo = $this->datos[2];
	}
	public function getId(){
		if($this->id != null){
			return $this->id;
		}
		else{
			return false;
		}
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getArchivo(){
		if($this->archivo != null){
			return $this->archivo;
		}
		else{
			return false;
		}
	}
	public function setArchivo($archivo){
		$this->archivo = $archivo;
	}
	public function Save(){
		if(parent::Insert($this->table,array("titulo" => $this->titulo, "archivo" => $this->archivo))){
			return true;
		}
		else{
			return false;
		}
	}
	public function Update(){
		if($this->id != null){
			if(parent::Update($this->table,array("titulo" =>$this->titulo,"archivo" =>$this->archivo),"id",$this->id)){
				return true;
			}
			else{
				return false;
			}
		}	
		else{
			return false;
		}
	}
	public function Delete(){
		if($this->id != null){
			if(parent::Delete($this->table,"id",$this->id)) {
				return true;
			} else {
				return false;
			}
		} 
		else {
			return flase;
		}
	}
}
?>