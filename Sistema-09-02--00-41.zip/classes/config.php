<?php
/*
* Modulo: Config
* Version: 0.1A
* Dependencias:
* --Database.
* 
* Manejador para configuraciones generales del sitio.
*/
class Config extends Database {
	private $id, $titulo, $nombre, $logo,$descripcion,$color;
	private $table;
	private $datos = array();
	public function __construct() {
		$this->table = "config";
		$this->setId("1");
		if(parent::Create($this->table,
		"id INT UNSIGNED AUTO_INCREMENT,nombre VARCHAR(128),titulo VARCHAR(128),descripcion TEXT,img INT,color VARCHAR(11),PRIMARY KEY(id)")){
			return true;
		}
		else{
			return false;
		}
	}
	public function setId($id){
		$this->id = $id;
		$this->datos = parent::Select("*",$this->table,"id",$id);
		$this->nombre = $this->datos[1];
		$this->titulo = $this->datos[2];
		$this->descripcion = $this->datos[3];
		$this->logo = $this->datos[4];
		$this->color = $this->datos[5];
	}
	public function getTitulo(){
		if($this->titulo != null){
			return $this->titulo;
		}
		else{
			return false;
		}
	}
	public function setTitulo($titulo){
		$this->titulo = $titulo;
	}
	public function getNombre(){
		if($this->nombre != null){
			return $this->nombre;
		}
		else{
			return false;
		}
	}
	public function setNombre($nombre){
		$this->nombre = $nombre;
	}
	public function getLogo(){
		if($this->logo != null){
			return $this->logo;
		}
		else{
			return false;
		}
	}
	public function setLogo($logo){
		$this->logo = $logo;
	}
	public function getDescripcion(){
		if($this->descripcion != null){
			return $this->descripcion;
		}
		else{
			return false;
		}
	}
	public function setDescripcion($descripcion){
		$this->descripcion = $descripcion;
	}
	public function getColor(){
		if($this->color != null){
			return $this->color;
		}
		else{
			return false;
		}
	}
	public function setColor($color){
		$this->color = $color;
	}
	public function Update(){
		if($this->id != null){
			if(parent::Update($this->table,array("titulo" =>$this->titulo,"nombre" =>$this->nombre,"logo" =>$this->logo,"descripcion" =>$this->descripcion,"color" =>$this->color),"id",$this->id)){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
}
?>