<h1>Lista de Publicaciones</h1>
<p>Aqui puede encontrar una lista de publicaciones</p>
<form>
	<input type="text">
	<input type="submit">
	<input type="password">
	<input type="checkbox">
	<select>
	</select>
</form>