<h1>Bienvenido!</h1>
<p>Esta es una pagina de incio de prueba</p>
<form>
	<input type="text">
	<input type="submit">
	<input type="password">
	<input type="checkbox">
	<select>
	</select>
</form>