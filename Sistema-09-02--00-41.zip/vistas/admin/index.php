<!DOCTYPE html>
<html>
<head>
	<?php
	require_once 'classes/imagenes.php';
	require_once 'classes/config.php';
	require_once 'classes/sesiones.php';
	require_once 'classes/usuarios.php';
	require_once 'classes/secadm.php';
	if(isset($_GET['id'])){
		$secid = $_GET['id'];
	}
	else{
		$secid = "0";
	}
	$sesion = new Sesion();
	if($sesion->Verificar() == false){
		return false;
	}
	$conf = new Config();
	$logoimg = new Imagen();
	$u = new Usuario();
	$userimg = new Imagen();
	$seccion = new SeccionAdmin();
	$seccion->setId($secid);
	$allsecs = $seccion->getAll("titulo");
	$logoimg->setId($conf->getLogo());
	$urllogo = $logoimg->getUrl();
	$titulo = $conf->getNombre();
	$u->setId($sesion->getId());
	$userimg->setId($u->getImagen());
	$urluser = $userimg->getUrl();
	$username = $u->getUser();
	?>
	<title><?php print $titulo." - Admin" ?></title>
	<meta charset="utf-8">
	<base href="http://localhost/poo/"></base>
	<link rel="stylesheet" type="text/css" href="contenido/css/admin.css">

	</head>
<body>
<div id="loader">
<div class="loader"></div>
</div>
	<script>
	var loader = document.getElementById('loader');
	var body = document.body;
	body.onload=function(){
		loader.setAttribute("style", "display:none");
    };
	</script> 
<header>
	<div id="logo">
	<img src="<?php print $urllogo; ?>">
	</div>
	<div id="user">
	<img src="<?php print $urluser; ?>">
	<h1><?php print $username; ?></h1>
	</div>
</header>
<section id="menu">
	<ul>
		<?php 
		foreach ($allsecs as $key => $value) {
			echo'<a href="admin/'.$value['id'].'"><li>'.$value['titulo'].'</li></a>';
		}
		?>
	</ul>
</section>
<section id="body">
	<?php
	include($seccion->getArchivo());
	?>
</section>
</body>
</html>