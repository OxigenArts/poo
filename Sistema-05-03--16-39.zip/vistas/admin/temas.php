<h1>Temas</h1>
<p>Elige un tema para mostar en la pagina principal de tu sitio.</p>
<section id="lista">
<?php
require_once 'classes/config.php';
require_once 'classes/temas.php';
require_once 'classes/imagenes.php';
$conf= new Config();
$tema = new Tema();
$alltemas = $tema->getAll();
foreach ($alltemas as $key => $value) {
	$urlimg = "vistas/temas/".$value['carpeta']."/foto.jpg";
	if(file_exists($urlimg)){
	$urlimg = $conf->getCfg("url")."vistas/temas/".$value['carpeta']."/foto.jpg";
	}
	else{
	$urlimg = $conf->getCfg("url")."vistas/temas/default.jpg";	
	}
	

	echo'<article class="mid">
		<h1>'.$value['titulo'].'</h1>
		<img src="'.$urlimg.'">
		<p>Autor: '.$value['autor'].'</p>
		<p>Descripcion: '.$value['descripcion'].'</p>
		<p>Fecha de Creación: '.$value['fecha'].'</p>';
		if($conf->getCfg("tema") == $value['id']){
			echo '<b>Tema activo</b>';
		}
		else{
			echo'<ul>
			<li>
				<form method="post">
					<input type="hidden" name="id" value="">
					<input name="activar" class="azul" value="Activar" type="submit">
				</form>
			</li>
			<li>
				<form method="post">
					<input type="hidden" name="id" value="">
					<input name="eliminar" class="rojo" value="Eliminar" type="submit">
				</form>
			</li>
		</ul>';
		}
	echo '</article>';
}
?>
</section>